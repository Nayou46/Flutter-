import 'package:flutter/material.dart';

void main() {
  runApp(LoginForm());
}

class LoginForm extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Login Form'),
        ),
        body: Padding(
          padding: EdgeInsets.all(20.0),
          child: LoginFormWidget(),
        ),
      ),
    );
  }
}

class LoginFormWidget extends StatefulWidget {
  @override
  _LoginFormWidgetState createState() => _LoginFormWidgetState();
}

class _LoginFormWidgetState extends State<LoginFormWidget> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _isChecked = false;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        TextField(
          controller: _emailController,
          decoration: InputDecoration(
            labelText: 'Email',
          ),
        ),
        SizedBox(height: 20.0),
        TextField(
          controller: _passwordController,
          obscureText: true,
          decoration: InputDecoration(
            labelText: 'Password',
          ),
        ),
        SizedBox(height: 20.0),
        Row(
          children: <Widget>[
            Checkbox(
              value: _isChecked,
              onChanged: (bool? value) {
                setState(() {
                  _isChecked = value!;
                });
              },
            ),
            Text('accepter les conditions'),
          ],
        ),
        SizedBox(height: 20.0),
        ElevatedButton(
          onPressed: () {
            // Action à effectuer lors de la soumission du formulaire
            String email = _emailController.text;
            String password = _passwordController.text;
            bool rememberMe = _isChecked;
            print('Email: $email\nPassword: $password\n accepter les conditions: $rememberMe');
            // Ajoutez ici la logique de validation et d'authentification
          },
          child: Text('Submit'),
        ),
      ],
    );
  }
}
